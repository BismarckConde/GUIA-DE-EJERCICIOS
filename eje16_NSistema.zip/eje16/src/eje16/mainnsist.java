package eje16;
import java.util.Scanner;
public class mainnsist {

	public static void main(String[] args) 
	{
		Scanner tc=new Scanner(System.in);
		double a,b,c,d,e,f; // ax+by=c y dx+ey=f
		 double X,Y,det;      // x=(ce-bf)/(ae-bd)  y=(af-cd)/(ae-bd)

		 System.out.println(" INGRESE LOS VALORES DE LAS SIGUIENTES VARIABLES ");
		 System.out.println(" INGRESE EL VALOR DE A");
		 a=tc.nextDouble();
		 System.out.println(" INGRESE EL VALOR DE B");
		 b=tc.nextDouble();
		 System.out.println(" INGRESE EL VALOR DE C");
		 c=tc.nextDouble();
		 System.out.println(" INGRESE EL VALOR DE D");
		 d=tc.nextDouble();
		 System.out.println(" INGRESE EL VALOR DE E");
		 e=tc.nextDouble();
		 System.out.println(" INGRESE EL VALOR DE F");
		 f=tc.nextDouble();
		 
		 det=(a*e)-(b*d);
		 X=(c*e)-(b*f)/det;
		 Y=(a*f)-(c*d)/det;
		 System.out.println(" POR LO TANTO LA SOLUCION DEL SISTEMA DE ESCUACIONES ES :"+" X="+X+" Y="+Y);
	}
}
