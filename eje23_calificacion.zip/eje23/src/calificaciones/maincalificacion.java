package calificaciones;
import java.util.Scanner;
public class maincalificacion {

	public static void main(String[] args) 
	{
		Scanner tc=new Scanner(System.in);
		double n;
		
		System.out.println(" INGRESE LA CALIFICACION DEL ALUMNO");
		n=tc.nextDouble();
		
		if(n>=60)
		{
			System.out.println(" EL ALUMNO ESTA APROBADO");
		}
		else 
		{
			System.out.println(" EL ALUMNO NO ESTA APROBADO");
		}
	}

}
