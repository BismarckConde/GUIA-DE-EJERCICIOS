package ejercicio_5;
import java.util.Scanner;
public class main {

	public static void main(String[] args) 
	{
		Scanner tc=new Scanner(System.in);
		 int x=1,x2;
		 int  y;
		 
		 System.out.println("*** SABIENDO QUE X=1 ENTONCES TENEMOS...***");
		 y=5*(x*x*x*x*x) + 2*(x*x*x*x) + 3*(x*x*x) + 7;
		 
		 System.out.println(" EL VALOR FINAL Y ES :"+y);
		 
		 System.out.println("*** CONSIDERANDO X COMO UN NUMERO CUALQUIERA...***");
		 
		 System.out.println(" INGRESE UN NUMERO PARA X");
		 x2=tc.nextInt();
		 System.out.println(" EL VALOR FINAL Y ES :"+y);
	}
}
