package tipotriangulo;
import java.util.Scanner;
public class maintriangulo {

	public static void main(String[] args)
	{
		Scanner tc=new Scanner(System.in);
		double lado1,lado2,lado3;
		double a,s;
		
		System.out.println("INGRESE EL PRIMER LADO DEL TRIANGULO");
		lado1=tc.nextDouble();
		System.out.println("INGRESE EL SEGUNDO LADO DEL TRIANGULO");
		lado2=tc.nextDouble();
		System.out.println("INGRESE EL TERCER LADO DEL TRIANGULO");
		lado3=tc.nextDouble();
		
		s=(lado1+lado2+lado3)/2;
		
		a=Math.sqrt(s*(s-lado1)*(s-lado2)*(s-lado3));
		
		System.out.println(" EL AREA DEL TRIANGULO CONOCIENDO SUS LADOS ES :"+a);
	}
}
