package eje27;
import java.util.Scanner;
public class mainpantalones 
{

	public static void main(String[] args) 
	{
		Scanner tc=new Scanner(System.in);
		int np;
		double p,ct;
		
		System.out.println(" INGRESE EL NUMERO DE PANTALONES QUE DESEA COMPRAR");
		np=tc.nextInt();
		
		if(np>3)
		{
		   p=10;
		}
		else
		{
			p=12;
		}
		ct=p*np;
		System.out.println(" EL COSTO TOTAL DE LOS PANTALONES QUE DESEA COMPRAR ES DE  $:"+ct+" DOLARES");
	}
}
