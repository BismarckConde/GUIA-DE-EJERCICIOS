package eje29;
import java.util.Scanner;
public class maindiferente {

	public static void main(String[] args) 
	{
		Scanner tc=new Scanner(System.in);
		int n1,n2,d,my,mn;
		
		System.out.println(" INGRESE EL PRIMER NUMERO");
		n1=tc.nextInt();
		System.out.println(" INGRESE EL SEGUNDO NUMERO");
		n2=tc.nextInt();
		
		my=Math.max(n1, n2);
		mn=Math.min(n1, n2);
		
		d=my-mn;
		System.out.println(" LA DIFERENCIA ENTRE EL MAYOR Y MENOR DE LOS NUMEROS INGRESADOS ES : "+d);
		System.out.println("EL NUMERO MAYOR ES :"+my+" EL NUMERO NENOR ES :"+mn);
	}
}
