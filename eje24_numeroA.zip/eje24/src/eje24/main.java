package eje24;
import java.util.Scanner;
public class main {

	public static void main(String[] args) 
	{
		Scanner tc=new Scanner(System.in);
		double n,y1,y2;
		
		System.out.println(" INGRESE EL NUMERO");
		n=tc.nextDouble();
		
		if (n>0)
		{
			y1=(double)Math.pow(2, n);
			System.out.println(" EL NUMERO QUE USTED INGRESO ES POSITIVO Y EL VALOR DE Y ES :"+y1);
		}
		else
		{
			y2=n+5;
			System.out.println(" EL NUMERO QUE USTED HA INGRESADO ES NEGATIVO Y EL VALOR DE Y ES ."+y2);
		}
	}
}
