package eje19;
import java.util.Scanner;
public class mainvotante {

	public static void main(String[] args) 
	{
		Scanner tc=new Scanner(System.in);
		int edad;
		
		System.out.println(" INGRESE LA EDAD");
		edad=tc.nextInt();
		
		if (edad <16)
		{
			System.out.println(" USTED AUN NO ES UNA PERSONA VOTANTE");
		}
		else
		{
			System.out.println(" USTED YA ES UNA PERSONA VOTANTE");
		}
	}
}
