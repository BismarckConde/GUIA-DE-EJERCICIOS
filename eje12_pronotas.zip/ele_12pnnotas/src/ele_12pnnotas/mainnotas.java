package ele_12pnnotas;
import java.util.Scanner;
public class mainnotas 
{

	public static void main(String[] args) 
	{
		Scanner tc=new Scanner(System.in);
		int n=0, i=0;
		double  nota;
		double suma=0,promedio;
		
		System.out.println(" POR FAVOR INGRESE LA CANTIDAD DE NOTAS A CALCULAR... ");
		n=tc.nextInt();
		
		while (i<n)
		{
			System.out.println(" INGRESE LA NOTA "+(i+1)+":");
			nota=tc.nextDouble();
			suma +=nota;
			i++;
		}
		promedio=suma/n;
				System.out.println(" EL PROMEDIO DE LAS NOTAS QUE USTED IMGRESO ES :"+promedio);
	}
}
