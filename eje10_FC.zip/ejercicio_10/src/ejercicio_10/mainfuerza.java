package ejercicio_10;
import java.util.Scanner;
public class mainfuerza 
{

	public static void main(String[] args) 
	{
		Scanner tc=new Scanner(System.in);
		
		double m,f,a;
		
		System.out.println(" INGRESE LA MASA DE CUERPO...");
		m=tc.nextDouble();
		System.out.println(" INGRESE LA ACELERACION EN M/S AL CUADRADO ");
		a=tc.nextDouble();
		
		f=m*a;
		System.out.println(" LA FUERZA DEL CUERPO ES :"+f);
	}

}
