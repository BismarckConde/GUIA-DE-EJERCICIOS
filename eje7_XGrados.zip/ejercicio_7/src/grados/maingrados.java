package grados;
import java.util.Scanner;
public class maingrados {

	public static void main(String[] args) 
	{
		Scanner tc=new Scanner(System.in);
		double fa;
		
		System.out.println(" INGRESE LOS GRADOS FAHRENHEIT...");
		fa=tc.nextDouble();
		
		double cel=0.5555*(fa-32);
				
		
		System.out.println(" LOS GRADOS FAHRENHEIT A CELSIUS EQUIVALEN A :"+cel);
	}
}
