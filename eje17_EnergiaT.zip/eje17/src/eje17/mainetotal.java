package eje17;
import java.util.Scanner;
public class mainetotal {

	public static void main(String[] args) 
	{
		Scanner tc=new Scanner(System.in);
		double ET,M,V,H;
		double G=9.814,EC,EP;
		 System.out.println("*********************************************************** ");
		 System.out.println(" INGRESE LOS SIGUIENTES DATOS PARA CALCULAR LA ENERGIA TOTAL");
		 System.out.println("*********************************************************** ");
		 
		 System.out.println(" INGRESE LA MASA DEL CUERPO");
		 M=tc.nextDouble();
		 System.out.println(" INGRESE LA VELOCIDAD DEL CUERPO");
		 V=tc.nextDouble();
		 System.out.println(" INGRESE LA ALTURA DEL CUERPO");
		 H=tc.nextDouble();
		 
		 EC=0.5*M*Math.pow(V, 2);
		 EP=M*H*G;
		 ET=EC*EP;
		 System.out.println(" LA ENERGIA TOTAL DEL CUERPO ES :"+ET+"J");
	}

}
