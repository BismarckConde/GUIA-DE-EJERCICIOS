package eje18;
import java.util.Scanner;
public class mainncifras {

	public static void main(String[] args) 
	{
		Scanner tc=new Scanner(System.in);
		int n,pd,sd,td;
		
		 System.out.println(" INGRESE UN NUMERO QUE TENGA TRES CIFRAS");
		 n=tc.nextInt();
		pd=n/100;
		sd=(n/10)%10;
		td=n%10;
		
		 System.out.println(" EL NUMERO DE 3 CIFRAS QUE HA INGRESADO ES :"+n+" E INVERTIDO SERIA :"+td+sd+pd);

	}

}
