package ejercicio_6;
import java.util.Scanner;

public class mainnkiloalibra {

	public static void main(String[] args) 
	{
		Scanner tc=new Scanner(System.in);
		double libra,kilogramo;
		
		System.out.println(" INGRESE LA CANTIDAD DE KILOGRAMOS A CONVERTIR ");
		kilogramo=tc.nextDouble();
		
		
		libra=kilogramo*2.2046;
		System.out.println(" LOS "+kilogramo+"KILOGRAMOS A LIBRAS EQUIVALEN A : "+libra);
		 
	}
}
