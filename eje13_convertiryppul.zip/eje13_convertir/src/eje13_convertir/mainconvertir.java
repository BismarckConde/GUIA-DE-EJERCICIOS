package eje13_convertir;
import java.util.Scanner;

public class mainconvertir {

	public static void main(String[] args) 
	{
		Scanner tc=new Scanner(System.in);
		double y,pies, pul;
		double lpul,c;
		
		System.out.println(" INGRESE LAS MEDIDAD EN YARDA , PIES Y PULGADAS");
		System.out.println("INTRODUSCA LAS YARDAS");
		y=tc.nextDouble();
		System.out.println(" INGRESE LOS PIES");
		pies=tc.nextDouble();
		System.out.println(" INGRESE LAS PULGADAS ");
		pul=tc.nextDouble();
		
		lpul=(y*36)+(pies*32)+pul;
		c = lpul*2.54;
		
		System.out.println(" LA CONVERSION A CENTRIMETROS ES :"+c);
		
	}

}
