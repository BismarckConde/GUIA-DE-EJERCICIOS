package eje26;
import java.util.Scanner;
public class maininciso {

	public static void main(String[] args) 
	{
		Scanner tc=new Scanner(System.in);
		 int XY,X,Y;
		 System.out.println(" INGRESE LOS VALORES DE XY");
		 XY=tc.nextInt();
		 
		 X=XY /10;
		 Y=XY % 10;
		  System.out.println("  LOS VALORES DE X SON :"+X+" LOS VALORES DE Y SON :"+Y);
	}

}
