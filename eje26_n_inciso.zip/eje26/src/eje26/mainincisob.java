package eje26;
import java.util.Scanner;
public class mainincisob 
{

	public static void main(String[] args) 
	{
		Scanner tc=new Scanner(System.in);
		int XYZ,X,Y,Z;
		
		System.out.println(" INGRESE LOS VALORES DE XYZ");
		XYZ=tc.nextInt();
		
		X=XYZ/100;
		Y=(XYZ/10)%10;
		Z=XYZ %10;
		
		System.out.println(" LOS VALOR DE X ES :"+X+" EL VALOR DE Y ES :"+Y+" EL VALOR DE Z ES :"+Z);
	}
}
