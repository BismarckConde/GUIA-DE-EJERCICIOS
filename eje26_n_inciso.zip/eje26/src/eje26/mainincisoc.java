package eje26;
import java.util.Scanner;
public class mainincisoc {

	public static void main(String[] args) 
	{
		Scanner tc=new Scanner(System.in);
		int XYZW,X,Y,Z,W;
		
		System.out.println(" INGRESE EL VALOR DE XYZW");
		XYZW=tc.nextInt();
		X= XYZW/1000;
		Y=(XYZW/100)%10;
		Z=(XYZW/10)%10;
		W= XYZW%10;
		
		System.out.println(" EL VALOR DE X ES ."+X+" EL VALOR DE Y ES :"+Y+" EL VALOR DE Z ES :"+Z+" EL VALOR DE W ES :"+W);
	}
}
