package volcil;
import java.util.Scanner;
public class mainvolcil 
{

	public static void main(String[] args) 
	{
		Scanner tc=new Scanner(System.in);
		double r,h,v;
		double PI=3.1416;
		
		System.out.println(" INGRESE EL RADIO DEL CILINDRO");
		r=tc.nextDouble();
		System.out.println(" INGRESE LA ALTURA DEL CILINDRO");
		h=tc.nextDouble();
		
		v=PI*h*r*r;
		System.out.println(" EL VOLUMEN DEL CILINDRO ES :"+v);
	}

}
