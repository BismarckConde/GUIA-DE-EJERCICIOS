package eje25;
import java.util.Scanner;
public class mainditres 
{

	public static void main(String[] args) 
	{
		Scanner tc=new Scanner(System.in);
		int n;
		
		System.out.println(" INGRESE UN NUMERO");
		n=tc.nextInt();
		
		if(n % 3==0)
		{
			System.out.println(" EL NUMERO QUE INGRESO ES DIVISIBLE ENTRE 3");
		}
		else
		{
			System.out.println(" EL NUMERO QUE USTED INGRESO NO ES DIVISIBLE ENTRE 3");
		}
	}
}
