package eje21;
import java.util.Scanner;
public class mainnegativo_positivo {

	public static void main(String[] args) 
	{
		Scanner tc=new Scanner(System.in);
		double n,x1,x2;
		
		System.out.println(" INGRESE UN NUMERO");
		n=tc.nextDouble();
		
		if (n<0)
		{
			x1=Math.pow(n, 4);
			System.out.println(" EL NUMERO QUE USTED INGRESO ES NEGATIVO Y SU VALOR ELEVADO A LA CUARTA ES :"+x1);
		}
		else
		{
			x2=Math.pow(n, 2);
			System.out.println(" EL NUMERO QUE USTED HA INGRESADO ES POSITIVO Y SU VALOR ELEVADO AL CUADRADO ES :"+x2);
		}

	}

}
