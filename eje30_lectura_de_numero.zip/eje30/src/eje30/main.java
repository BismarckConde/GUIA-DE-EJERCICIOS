package eje30;
import java.util.Scanner;
public class main {

	public static void main(String[] args) 
	{
		Scanner tc=new Scanner(System.in);
		int x,y,resta,suma,sumac;
		double divi,raizc;
		
		System.out.println(" INGRESE EL VALOR DE X");
		x=tc.nextInt();
		System.out.println(" INGRESE EL VALOR DE Y");
		y=tc.nextInt();
		
		if (x<0 && y<0)
		{
			sumac=(x*x)+(y*y);
					System.out.println(" SUMA DE CUADRADO ES : "+sumac);
		}
		else if(x<0 && y>0)
		{
			resta=x-y;
			System.out.println(" LA RESTA DE LOS VALORES INGRESADOS ES : "+resta);
		}
		else if(x>0 && y<0)
		{
			divi= x/y;
			System.out.println(" LA DIVISION ENTRE LOS NUMERO INGRESADOS ES : "+divi);
		}
		else
		{
			if (x>y)
			{
				suma=x+y;
				System.out.println(" LA SUMA DE LOS NUMEROS INGRESADOS ES : "+suma);
			}
			else 
			{
				raizc=Math.sqrt(x);
				System.out.println(" LA RAIZ CUADRADA ES : "+raizc);
			}
		}

	}
}
