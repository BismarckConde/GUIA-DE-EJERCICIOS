package ejercico_1;
import java.util.Scanner;

public class main_arearec 
{

	public static void main(String[] args) 
	{
		Scanner tc=new Scanner(System.in);
		int a,b,h;
		
		System.out.println(" *** PROGRAMA PARA CALCULAR EL AREA DE RECTANGULO *** ");
		
		System.out.println(" INGRESE LA BASE DEL RECTANGULO");
		b=tc.nextInt();
		System.out.println(" INGRESE LA ALTURA DEL RECTANGULO");
		h=tc.nextInt();
		
		a=b*h;
		System.out.println(" EL AREA DEL RECTANGULO ES :"+a);
	}
}
