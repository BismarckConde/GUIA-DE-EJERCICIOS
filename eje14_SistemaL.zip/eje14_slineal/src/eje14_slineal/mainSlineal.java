package eje14_slineal;
import java.util.Scanner;
public class mainSlineal {

	public static void main(String[] args) 
	{
		Scanner tc=new Scanner(System.in);
		
		double a,b;
		double x;
		System.out.println("***********************************************");
		System.out.println(" BIENVENIDO AL PROGRAMA DE ECUACIONES LINEALES ");
		System.out.println("***********************************************");
		System.out.println(" POR FAVOR INGRESE EL VALOR DE A");
		a=tc.nextInt();
		System.out.println(" POR FAVOR INGRESE EL VALOR DE B");
		b=tc.nextInt();
		
		if (a==0 && b==0)
		{
			System.out.println(" LA ECUACION LINEAL CON LOS VALORES INGRESADO TINENE SOLUCIONES INFINITAS");
		}
		else if(a==0 && b!=0)
		{
			System.out.println("  LA ECUACION LINEAL CON LOS VALORES INGRESADOS NO TIENE SOLUCION ");
		}
		else 
		{
			x=-b/a;
			System.out.println(" LA SOLUCION DE LA ECUACION ES X ="+x);
		}
	   }
	 }

