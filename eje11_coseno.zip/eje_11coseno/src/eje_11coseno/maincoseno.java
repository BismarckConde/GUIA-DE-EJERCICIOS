package eje_11coseno;
import java.util.Scanner;
public class maincoseno 
{

	public static void main(String[] args) 
	{
		Scanner tc=new Scanner(System.in);
		double n;
		double cos;
		
		System.out.println(" INGRESE UN NUMERO PARA CALCULAR SU COSENO");
		n=tc.nextDouble();
		
		cos=Math.cos(n);
		
		System.out.println(" EL COSENO DE "+n+" ES:"+cos);
		
	}

}
