package ejercicio_3;
import java.util.Scanner;
public class main {

	public static void main(String[] args) 
	{
		Scanner tc=new Scanner(System.in);
		 double C=2.5;
		 double y,x1=2,x2;
		 
		 // a) x=2
		System.out.println("*** SABIENDO QUE X=2 TENEMOS COMO RESULTADO...***");
		y=x1*C-2;
		
		System.out.println("EL VALOR DE Y CUANDO X="+x1+" Y C="+C+" ES :"+y);
		
		
		System.out.println("*** CONSIDERANDO X COMO UN NUMERO CUALQUIERA...***");
		System.out.println(" INGRESE EL VALOR DE X");
		x2=tc.nextDouble();
		y=x2*C-2;
		System.out.println(" EL VALOR DE Y CUANDO X="+x2+" Y C="+C+" ES :"+y);
	}
}
