package eje20;
import java.util.Scanner;
public class mainpar_impar {

	public static void main(String[] args) 
	{
		Scanner tc=new Scanner(System.in);
		int n;
		
		System.out.println(" INGRESE UN NUMERO");
		n=tc.nextInt();
		
		if(n % 2==0)
		{
			System.out.println(" EL NUMERO QUE INGRESO ES PAR");
		}
		else
		{
			System.out.println(" EL NUMERO QUE INGRESO ES IMPAR");
		}
	}

}
