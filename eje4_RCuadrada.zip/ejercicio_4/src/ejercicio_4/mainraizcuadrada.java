package ejercicio_4;
import java.util.Scanner;

public class mainraizcuadrada {

	public static void main(String[] args) 
	{
		Scanner tc =new Scanner(System.in);
		double num;
		double raiz;
		System.out.println(" INGRESE UN MUNERO PARA CALCULAR SU RAIZ CUADRADA");
		num=tc.nextDouble();
		double raiz1=Math.sqrt(num);
		
		System.out.println(" LA RAIZ CUADRADA DEL NUMERO QUE USTED HA INGRESADO ES :"+raiz1);
	}

}
