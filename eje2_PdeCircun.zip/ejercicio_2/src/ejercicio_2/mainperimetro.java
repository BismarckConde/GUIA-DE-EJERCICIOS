package ejercicio_2;
import java.util.Scanner;

public class mainperimetro 
{

	public static void main(String[] args) 
	{
		Scanner tc= new Scanner(System.in);
		int radiocircunferencia,radio;
		double a1,a2;
		double PI=3.1416;
		
		System.out.println("  INGRESE EL RADIO DE LA CIRCUNFERENCIA");
		radiocircunferencia=tc.nextInt();
		
		System.out.println("  INGRESE EL RADIO DE LA CIRCULO");
		radio=tc.nextInt();
		
		
		a1=2*PI*radiocircunferencia;
		a2=PI*radio*radio;
		
		System.out.println(" EL AREA DE LA CIRCUNFERENCIA ES : "+a1+"\n EL AREA DEL CIRCULO ES :"+a2);
	}
}
