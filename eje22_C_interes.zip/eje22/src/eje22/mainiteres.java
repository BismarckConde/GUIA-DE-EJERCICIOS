package eje22;
import java.util.Scanner;
public class mainiteres 
{

	public static void main(String[] args) 
	{
		Scanner tc=new Scanner(System.in);
		double C,I=0.06,CT,TI =0.07;
		
		System.out.println(" INGRESE EL CAPITAL");
		C=tc.nextDouble();
		
		if(C>10000)
		{
			TI=0.07;
		}
		I=C*TI;
		CT=C+I;
		System.out.println(" EL CAPITAL TOTAL ES DE : $"+CT);	
	}
}
