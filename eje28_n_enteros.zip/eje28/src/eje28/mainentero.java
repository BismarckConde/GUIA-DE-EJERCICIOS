package eje28;
import java.util.Scanner;
public class mainentero {

	public static void main(String[] args) 
	{
		Scanner tc=new Scanner(System.in);
		
		int n1,n2;
		System.out.println(" INGRESE EL PRIMER NUMERO");
		n1=tc.nextInt();
		System.out.println(" INGRESE EL SEGUNDO NUMERO ");
		n2=tc.nextInt();
		
		if ((n1>0 && n2<0) || (n1<0 && n2>0))
		{
			System.out.println(" LOS NUMEROS QUE HA INGRESADO SI TIENEN SIGNOS OPUESTOS");
		}
		else 
		{
			System.out.println(" LOS NUMEROS QUE HA INGRESADO NO TIENEN SIGNOS OPUESTOS ");
		}
	}
}
